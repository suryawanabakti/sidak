<?php

namespace App\Filament\Resources\DosenResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Facades\Storage;

class PatenRelationManager extends RelationManager
{
    protected static string $relationship = 'paten';

    public  function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Form Paten')->description('Paten adalah hak eksklusif yang diberikan oleh negara kepada penemu atas hasil invensi (penemuannya) di bidang teknologi untuk jangka waktu tertentu.')
                    ->schema([
                        FileUpload::make('sertifikat')->directory('paten/' . $this->getOwnerRecord()->username)
                            ->acceptedFileTypes(['application/pdf'])->required(),
                        Grid::make(2)->schema([
                            DatePicker::make('tanggal')->required(),
                            TextInput::make('judul')->required(),
                        ]),
                        Textarea::make('anggota')->required()
                    ])
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('judul')
            ->columns([
                Tables\Columns\TextColumn::make('judul')->searchable()->sortable(),
                TextColumn::make('sertifikat')->searchable()
                    ->label('Download File')
                    ->formatStateUsing(fn($state) => basename($state)) // Menampilkan hanya nama file
                    ->url(fn($record) => Storage::url($record->sertifikat)) // Membuat URL file
                    ->openUrlInNewTab() // Buka file di tab baru
                    ->icon('heroicon-o-arrow-down-on-square') // Tambahkan ikon download
                    ->color('primary')
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ViewAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
