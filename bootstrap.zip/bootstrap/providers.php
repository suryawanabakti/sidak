<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FilamentServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\DosenPanelProvider::class,
    App\Providers\Filament\PimpinanPanelProvider::class,
    App\Providers\Filament\TendikPanelProvider::class,
];
